import React from "react";

function Paciente_home() {
   return(
      <>
         <h1>Paciente_home</h1>
      </>
   )
}

export default Paciente_home;