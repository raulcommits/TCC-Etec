import React from "react";

function Home_Paciente() {
    return(
        <>
            <h1>Home_Paciente</h1>
        </>
    )
}

export default Home_Paciente;