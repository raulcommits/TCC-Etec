import React from "react";
import "./Agente.css"
import Header from "../../components/Header/Header"

function Agente_home() {
   return(
      <>
         <Header/>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
         <h1>Página Agente_home</h1>
      </>
   )
}

export default Agente_home;