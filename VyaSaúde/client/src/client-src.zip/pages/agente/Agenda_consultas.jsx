import React from "react";

function Agenda_Consultas() {
    return(
        <>
            <h1>Agenda_Consultas</h1>
        </>
    )
}

export default Agenda_Consultas;