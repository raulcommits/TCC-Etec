import React from "react";

function Cadastro_Pacientes() {
    return(
        <>
            <h1>Cadastro_Pacientes</h1>
        </>
    )
}

export default Cadastro_Pacientes;